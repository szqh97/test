#!/usr/bin/nev python
application_service_name='vDashboard'

db_vtweb_host='192.168.1.19'
db_vtweb_database="vdash_tracker"
db_vtweb_username="vddb"
db_vtweb_password='123456'

earth_database='vdash_mddb'
usermanager_database='vdash_usermanager'

db_vdashboard_host='192.168.1.19'
db_vdashboard_database='vdashboard_bobo'
db_vdashboard_username='vddb'
db_vdashboard_password='123456'


control_db_host='192.168.1.19'
control_db_database='vdash_p2pwarehouse'
control_db_username='vddb'
control_db_password='123456'

#1_0_2_0\u65b0\u589e
db_archived_host='192.168.1.54'
db_archived_database='trackerarchived'
db_archived_username='abc'
db_archived_password='123'
