#!/usr/bin/env python

get_samplesite_ids_sql = '''select trackingWebsite_id from dailyViewsBasicSample where company_id = %d'''

get_infringing_matches_by_date_meta_site_sql = '''select id, company_id, trackingMeta_id, trackingWebsite_id, created_at, post_date,\
        matchedFile_id from matchedVideo where trackingWebsite_id in (%s) and trackingMeta_id = %d and company_id = %d and \
        hide_flag = 2 and created_at  < '%s' + interval 1 day  and (takeoff_time = 0 or takeoff_time > '%s')'''

# earth_database.meta
get_tracking_meta_list = '''select b.id meta_id, b.meta_title meta_title, b.meta_type meta_type, a.company_id company_id, \
        b.release_date release_date from metaExtraInfo a, %s.meta b where a.company_id = %d and b.company_id = a.company_id \
        and a.meta_id = b.id  and a.trackingSetting_id > 0'''

# earth_database.trackingWebsite
get_tracking_website_by_type = '''select b.id trackingWebsite_id from company_website a , %s.trackingWebsite b where a.tracking_website_id = b.id and a.company_id = %d and b.website_type in (%s)'''
