#!/usr/bin/env python
import pandas as pd
import numpy as np
import logging
import traceback



import torndb
import db_config
import vdashboard_sql

logger = logging.getLogger('vdashboard_util')
formatter = logging.Formatter('%(threadName)s %(asctime)s %(name)-15s %(levelname)-8s: %(message)s\n')
file_handler = logging.FileHandler('/tmp/vdashboard_util.log')
file_handler.setFormatter(formatter)
stdout_stream = logging.StreamHandler(sys.stdout)
logger.addHandler(file_handler)
logger.addHandler(stdout_stream)
logger.setLevel(logging.DEBUG)


vdasbboard_db_conn  = torndb.Connection(db_vdashboard_host, db_vdashboard_database, user=db_vdashboard_username, password=db_vdashboard_password)
vtweb_db_conn       = torndb.Connection(db_vtweb_host, db_vtweb_database, user = db_vtweb_username, password = db_vtweb_password)
archive_db_conn     = torndb.Connection(db_archived_host, db_archived_database, user = db_archived_username, password = db_archived_password)
def get_samplesite_ids(db_conn, company_id=14):
    sql = vdashboard_sql.get_samplesite_ids_sql % (company_id)

    try:
        res = db_conn.get(sql)
        return [x.trackingWebsite_id for x in res]
    except Exception, err:
        logger.error("==get_samplesite_ids== %s", str(traceback.format_exc()))
        pass
    finally:
        return None

def get_tracking_meta_list(db_conn, earth_database = "vdash_mddb", company_id = 14):
    '''
     query tracking meta list in vtweb_tracker
    '''
    sql = vdashboard_sql.get_tracking_meta_list %(earth_database, company_id)
    try:
        res = db_conn.query(sql)
        return res
    except Exception, err:
        logger.error("==get_tracking_meta_list== %s", str(traceback.format_exc()))
    finally:
        return None

def get_tracking_website_id_list(db_conn, earth_database = 'vdash_mddb', company_id = 14, website_type = '"ugc"'):
    '''
    get all tracking website id by website type 
    '''
    sql = vdashboard_sql.get_tracking_website_by_type % (earth_database, company_id, website_type)
    try:
        res = db_conn.query(sql)
        return [x.trackingWebsite_id for x in res]
    except Exception, err:
        logger.error('==get_tracking_website_id_list== %s', str(traceback.format_exc()))
    finally:
        return None

def get_estimated_ugc_site():
    sample_site_ids = get_samplesite_ids(vdasbboard_db_conn)
    tracking_site_ids = get_tracking_website_id_list(vtweb_db_conn, earth_database = 'vdash_mddb')
    if sample_site_ids and tracking_site_ids:
        return [x for x in tracking_site_ids if x not in sample_site_ids]

def get_matched_videos(db_conn, report_at, trackingMeta_id ):
    all_ugc_site_ids = get_tracking_website_id_list(vtweb_db_conn, earth_database = 'vdash_mddb', website_type = '"ugc"')
    sql = vdashboard_sql.get_infringing_matches_by_date_meta_site_sql %()
    pass

def get_archived_matched_video(db_conn, report_at, trackingMeta_id):
    pass



