#!/usr/bin/env python
import os
import sys
import struct
dnafile = sys.argv[1]

with file(dnafile, 'r') as f:
    h = f.read(24)
    h = struct.unpack('4iq', h)
    begint_ts = h[4]
    print begint_ts
    f.seek(-64,2)
    dna = f.read(40)
    d = struct.unpack('I', dna[0:4])
    print begint_ts + d[0]
    
